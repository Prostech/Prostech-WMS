﻿namespace Prostech.WMS.API.Models
{
    public class DatabaseConnection
    {
        public string WMS { get; set; }
    }
}
