﻿namespace Prostech.WMS.BLL.Helpers.Wrapper
{
    public static class ServiceConstants
    {
        public static int TotalRecords = 0;
        public static void SetTotalRecords(int totalRows)
        {
            TotalRecords = totalRows;
        }
    }
}
