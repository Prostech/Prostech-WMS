﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Prostech.WMS.DAL.Migrations
{
    /// <inheritdoc />
    public partial class InitDb : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "public");

            migrationBuilder.CreateTable(
                name: "ActionType",
                schema: "public",
                columns: table => new
                {
                    ActionTypeId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ActionName = table.Column<string>(type: "text", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    CreatedBy = table.Column<int>(type: "integer", nullable: true),
                    ModifiedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: true),
                    GUID = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ActionType", x => x.ActionTypeId);
                });

            migrationBuilder.CreateTable(
                name: "Brand",
                schema: "public",
                columns: table => new
                {
                    BrandId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    BrandName = table.Column<string>(type: "text", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    CreatedBy = table.Column<int>(type: "integer", nullable: true),
                    ModifiedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: true),
                    GUID = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Brand", x => x.BrandId);
                });

            migrationBuilder.CreateTable(
                name: "Category",
                schema: "public",
                columns: table => new
                {
                    CategoryId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    CategoryName = table.Column<string>(type: "text", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    CreatedBy = table.Column<int>(type: "integer", nullable: true),
                    ModifiedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: true),
                    GUID = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Category", x => x.CategoryId);
                });

            migrationBuilder.CreateTable(
                name: "ProductItemStatus",
                schema: "public",
                columns: table => new
                {
                    ProductItemStatusId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ProductItemStatusName = table.Column<string>(type: "text", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    CreatedBy = table.Column<int>(type: "integer", nullable: true),
                    ModifiedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: true),
                    GUID = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductItemStatus", x => x.ProductItemStatusId);
                });

            migrationBuilder.CreateTable(
                name: "User",
                schema: "public",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Fullname = table.Column<string>(type: "text", nullable: false),
                    Email = table.Column<string>(type: "text", nullable: false),
                    Phone = table.Column<string>(type: "text", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    CreatedBy = table.Column<int>(type: "integer", nullable: true),
                    ModifiedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: true),
                    GUID = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_User", x => x.UserId);
                });

            migrationBuilder.CreateTable(
                name: "ActionHistory",
                schema: "public",
                columns: table => new
                {
                    ActionHistoryId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ActionTypeId = table.Column<int>(type: "integer", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    CreatedBy = table.Column<int>(type: "integer", nullable: true),
                    ModifiedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: true),
                    GUID = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ActionHistory", x => x.ActionHistoryId);
                    table.ForeignKey(
                        name: "FK_ActionHistory_ActionType_ActionTypeId",
                        column: x => x.ActionTypeId,
                        principalSchema: "public",
                        principalTable: "ActionType",
                        principalColumn: "ActionTypeId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Product",
                schema: "public",
                columns: table => new
                {
                    ProductId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ProductName = table.Column<string>(type: "text", nullable: false),
                    Description = table.Column<string>(type: "text", nullable: false),
                    BrandId = table.Column<int>(type: "integer", nullable: false),
                    CategoryId = table.Column<int>(type: "integer", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    CreatedBy = table.Column<int>(type: "integer", nullable: true),
                    ModifiedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: true),
                    GUID = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Product", x => x.ProductId);
                    table.ForeignKey(
                        name: "FK_Product_Brand_BrandId",
                        column: x => x.BrandId,
                        principalSchema: "public",
                        principalTable: "Brand",
                        principalColumn: "BrandId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Product_Category_CategoryId",
                        column: x => x.CategoryId,
                        principalSchema: "public",
                        principalTable: "Category",
                        principalColumn: "CategoryId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "UserAccount",
                schema: "public",
                columns: table => new
                {
                    UserName = table.Column<string>(type: "text", nullable: false),
                    Password = table.Column<string>(type: "text", nullable: false),
                    UserId = table.Column<int>(type: "integer", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    CreatedBy = table.Column<int>(type: "integer", nullable: true),
                    ModifiedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: true),
                    GUID = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserAccount", x => x.UserName);
                    table.ForeignKey(
                        name: "FK_UserAccount_User_UserId",
                        column: x => x.UserId,
                        principalSchema: "public",
                        principalTable: "User",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProductItem",
                schema: "public",
                columns: table => new
                {
                    SKU = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ProductId = table.Column<int>(type: "integer", nullable: false),
                    Price = table.Column<decimal>(type: "numeric", nullable: false),
                    IsStock = table.Column<bool>(type: "boolean", nullable: false),
                    LatestInboundTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    LatestOutboundTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    ProductItemStatusId = table.Column<int>(type: "integer", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    CreatedBy = table.Column<int>(type: "integer", nullable: true),
                    ModifiedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: true),
                    GUID = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductItem", x => x.SKU);
                    table.ForeignKey(
                        name: "FK_ProductItem_ProductItemStatus_ProductItemStatusId",
                        column: x => x.ProductItemStatusId,
                        principalSchema: "public",
                        principalTable: "ProductItemStatus",
                        principalColumn: "ProductItemStatusId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProductItem_Product_ProductId",
                        column: x => x.ProductId,
                        principalSchema: "public",
                        principalTable: "Product",
                        principalColumn: "ProductId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ActionHistoryDetail",
                schema: "public",
                columns: table => new
                {
                    SKU = table.Column<int>(type: "integer", nullable: false),
                    ActionHistoryId = table.Column<int>(type: "integer", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    CreatedBy = table.Column<int>(type: "integer", nullable: true),
                    ModifiedTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: true),
                    GUID = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ActionHistoryDetail", x => new { x.SKU, x.ActionHistoryId });
                    table.ForeignKey(
                        name: "FK_ActionHistoryDetail_ActionHistory_ActionHistoryId",
                        column: x => x.ActionHistoryId,
                        principalSchema: "public",
                        principalTable: "ActionHistory",
                        principalColumn: "ActionHistoryId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ActionHistoryDetail_ProductItem_SKU",
                        column: x => x.SKU,
                        principalSchema: "public",
                        principalTable: "ProductItem",
                        principalColumn: "SKU",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                schema: "public",
                table: "ActionType",
                columns: new[] { "ActionTypeId", "ActionName", "CreatedBy", "CreatedTime", "IsActive", "ModifiedBy", "ModifiedTime" },
                values: new object[,]
                {
                    { 1, "Inbound", 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(5042), true, null, null },
                    { 2, "Outbound", 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(5044), true, null, null }
                });

            migrationBuilder.InsertData(
                schema: "public",
                table: "Brand",
                columns: new[] { "BrandId", "BrandName", "CreatedBy", "CreatedTime", "IsActive", "ModifiedBy", "ModifiedTime" },
                values: new object[,]
                {
                    { 1, "Apple", 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(6750), true, null, null },
                    { 2, "Samsung", 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(6752), true, null, null },
                    { 3, "Asus", 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(6753), true, null, null },
                    { 4, "Xiaomi", 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(6755), true, null, null },
                    { 5, "Sony", 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(6756), true, null, null }
                });

            migrationBuilder.InsertData(
                schema: "public",
                table: "Category",
                columns: new[] { "CategoryId", "CategoryName", "CreatedBy", "CreatedTime", "IsActive", "ModifiedBy", "ModifiedTime" },
                values: new object[,]
                {
                    { 1, "Laptop", 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(8442), true, null, null },
                    { 2, "Smart phone", 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(8444), true, null, null },
                    { 3, "Earbuds", 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(8445), true, null, null }
                });

            migrationBuilder.InsertData(
                schema: "public",
                table: "ProductItemStatus",
                columns: new[] { "ProductItemStatusId", "CreatedBy", "CreatedTime", "IsActive", "ModifiedBy", "ModifiedTime", "ProductItemStatusName" },
                values: new object[,]
                {
                    { 1, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(4114), true, null, null, "New" },
                    { 2, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(4116), true, null, null, "Second-hand" }
                });

            migrationBuilder.InsertData(
                schema: "public",
                table: "User",
                columns: new[] { "UserId", "CreatedBy", "CreatedTime", "Email", "Fullname", "IsActive", "ModifiedBy", "ModifiedTime", "Phone" },
                values: new object[,]
                {
                    { 1, 1, new DateTime(2023, 6, 14, 9, 59, 14, 374, DateTimeKind.Utc).AddTicks(7291), "phat.vo@rozitek.com", "Vo Tan Phat", true, null, null, "123" },
                    { 2, 1, new DateTime(2023, 6, 14, 9, 59, 14, 374, DateTimeKind.Utc).AddTicks(7294), "hai.tran@rozitek.com", "Tran Hung Hai", true, null, null, "456" }
                });

            migrationBuilder.InsertData(
                schema: "public",
                table: "ActionHistory",
                columns: new[] { "ActionHistoryId", "ActionTypeId", "CreatedBy", "CreatedTime", "IsActive", "ModifiedBy", "ModifiedTime" },
                values: new object[,]
                {
                    { 1, 1, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(3693), true, null, null },
                    { 2, 2, 1, new DateTime(2023, 6, 14, 10, 59, 14, 371, DateTimeKind.Utc).AddTicks(3696), true, null, null }
                });

            migrationBuilder.InsertData(
                schema: "public",
                table: "Product",
                columns: new[] { "ProductId", "BrandId", "CategoryId", "CreatedBy", "CreatedTime", "Description", "IsActive", "ModifiedBy", "ModifiedTime", "ProductName" },
                values: new object[,]
                {
                    { 1, 1, 1, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(5849), "Mô tả", true, null, null, "Iphone 14" },
                    { 2, 2, 1, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(5851), "Mô tả", true, null, null, "Samsung Galaxy S23" },
                    { 3, 3, 2, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(5853), "Mô tả", true, null, null, "Asus ROG" },
                    { 4, 1, 3, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(5854), "Mô tả", true, null, null, "Airpod" },
                    { 5, 4, 2, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(5855), "Mô tả", true, null, null, "Xiaomi Plus 9" }
                });

            migrationBuilder.InsertData(
                schema: "public",
                table: "UserAccount",
                columns: new[] { "UserName", "CreatedBy", "CreatedTime", "IsActive", "ModifiedBy", "ModifiedTime", "Password", "UserId" },
                values: new object[,]
                {
                    { "admin", 1, new DateTime(2023, 6, 14, 9, 59, 14, 374, DateTimeKind.Utc).AddTicks(5850), true, null, null, "Rozitek123@#", 1 },
                    { "hai.tran", 1, new DateTime(2023, 6, 14, 9, 59, 14, 374, DateTimeKind.Utc).AddTicks(5848), true, null, null, "123456", 2 },
                    { "phat.vo", 1, new DateTime(2023, 6, 14, 9, 59, 14, 374, DateTimeKind.Utc).AddTicks(5845), true, null, null, "123456", 1 }
                });

            migrationBuilder.InsertData(
                schema: "public",
                table: "ProductItem",
                columns: new[] { "SKU", "CreatedBy", "CreatedTime", "IsStock", "LatestInboundTime", "LatestOutboundTime", "ModifiedBy", "ModifiedTime", "Price", "ProductId", "ProductItemStatusId" },
                values: new object[,]
                {
                    { 1, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2690), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2691), null, null, null, 20000000m, 1, 1 },
                    { 2, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2693), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2694), null, null, null, 20000000m, 1, 1 },
                    { 3, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2695), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2696), null, null, null, 20000000m, 1, 1 },
                    { 4, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2697), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2698), null, null, null, 20000000m, 1, 1 },
                    { 5, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2699), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2700), null, null, null, 21000000m, 1, 1 },
                    { 6, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2701), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2701), null, null, null, 27000000m, 2, 1 },
                    { 7, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2707), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2707), null, null, null, 27000000m, 2, 1 },
                    { 8, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2709), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2709), null, null, null, 27000000m, 2, 1 },
                    { 9, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2711), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2711), null, null, null, 27000000m, 2, 1 },
                    { 10, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2712), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2713), null, null, null, 40000000m, 3, 1 },
                    { 11, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2714), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2715), null, null, null, 40000000m, 3, 1 },
                    { 12, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2716), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2717), null, null, null, 4000000m, 4, 1 },
                    { 13, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2718), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2718), null, null, null, 4000000m, 5, 1 },
                    { 14, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2720), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2720), null, null, null, 4000000m, 5, 1 },
                    { 15, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2722), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2722), null, null, null, 4000000m, 5, 1 },
                    { 16, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2724), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2725), null, null, null, 20000000m, 2, 1 },
                    { 17, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2726), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2727), null, null, null, 40000000m, 3, 1 },
                    { 18, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2728), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2728), null, null, null, 40000000m, 3, 1 },
                    { 19, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2730), false, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2730), new DateTime(2023, 6, 14, 10, 59, 14, 372, DateTimeKind.Utc).AddTicks(2731), null, null, 43000000m, 3, 1 },
                    { 20, 1, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2734), true, new DateTime(2023, 6, 14, 9, 59, 14, 372, DateTimeKind.Utc).AddTicks(2734), null, null, null, 28000000m, 2, 1 }
                });

            migrationBuilder.InsertData(
                schema: "public",
                table: "ActionHistoryDetail",
                columns: new[] { "ActionHistoryId", "SKU", "CreatedBy", "CreatedTime", "IsActive", "ModifiedBy", "ModifiedTime" },
                values: new object[,]
                {
                    { 1, 1, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1572), true, null, null },
                    { 1, 2, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1576), true, null, null },
                    { 1, 3, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1577), true, null, null },
                    { 1, 4, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1581), true, null, null },
                    { 1, 5, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1582), true, null, null },
                    { 1, 6, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1583), true, null, null },
                    { 1, 7, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1585), true, null, null },
                    { 1, 8, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1586), true, null, null },
                    { 1, 9, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1587), true, null, null },
                    { 1, 10, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1588), true, null, null },
                    { 1, 11, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1589), true, null, null },
                    { 1, 12, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1590), true, null, null },
                    { 1, 13, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1591), true, null, null },
                    { 1, 14, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1592), true, null, null },
                    { 1, 15, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1593), true, null, null },
                    { 1, 16, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1595), true, null, null },
                    { 1, 17, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1596), true, null, null },
                    { 1, 18, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1597), true, null, null },
                    { 1, 19, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1598), true, null, null },
                    { 2, 19, 1, new DateTime(2023, 6, 14, 10, 59, 14, 371, DateTimeKind.Utc).AddTicks(1600), true, null, null },
                    { 1, 20, 1, new DateTime(2023, 6, 14, 9, 59, 14, 371, DateTimeKind.Utc).AddTicks(1599), true, null, null }
                });

            migrationBuilder.CreateIndex(
                name: "IX_ActionHistory_ActionTypeId",
                schema: "public",
                table: "ActionHistory",
                column: "ActionTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_ActionHistoryDetail_ActionHistoryId",
                schema: "public",
                table: "ActionHistoryDetail",
                column: "ActionHistoryId");

            migrationBuilder.CreateIndex(
                name: "IX_Product_BrandId",
                schema: "public",
                table: "Product",
                column: "BrandId");

            migrationBuilder.CreateIndex(
                name: "IX_Product_CategoryId",
                schema: "public",
                table: "Product",
                column: "CategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductItem_ProductId",
                schema: "public",
                table: "ProductItem",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductItem_ProductItemStatusId",
                schema: "public",
                table: "ProductItem",
                column: "ProductItemStatusId");

            migrationBuilder.CreateIndex(
                name: "IX_UserAccount_UserId",
                schema: "public",
                table: "UserAccount",
                column: "UserId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ActionHistoryDetail",
                schema: "public");

            migrationBuilder.DropTable(
                name: "UserAccount",
                schema: "public");

            migrationBuilder.DropTable(
                name: "ActionHistory",
                schema: "public");

            migrationBuilder.DropTable(
                name: "ProductItem",
                schema: "public");

            migrationBuilder.DropTable(
                name: "User",
                schema: "public");

            migrationBuilder.DropTable(
                name: "ActionType",
                schema: "public");

            migrationBuilder.DropTable(
                name: "ProductItemStatus",
                schema: "public");

            migrationBuilder.DropTable(
                name: "Product",
                schema: "public");

            migrationBuilder.DropTable(
                name: "Brand",
                schema: "public");

            migrationBuilder.DropTable(
                name: "Category",
                schema: "public");
        }
    }
}
