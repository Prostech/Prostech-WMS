﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prostech.WMS.DAL.DTOs.UserAccount
{
    public class TokenCriteria
    {
        public string Token { get; set; }
    }
}
